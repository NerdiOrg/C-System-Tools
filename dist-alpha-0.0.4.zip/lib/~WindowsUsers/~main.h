// FolderScanner.h
#pragma once
#include <vector>
#include <filesystem>
std::string random_aZ09(const std::string& prefix, const size_t& length, const std::string& suffix); // returns random string (using time(0)) with optional prefix/suffix