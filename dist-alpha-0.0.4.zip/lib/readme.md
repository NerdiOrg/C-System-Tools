## Internal Library

The 'lib' folder contains functions that are created by me, for this C++ project or taken from my other personal work. This is different than the 'ext' folder which contains third-party dependencies.